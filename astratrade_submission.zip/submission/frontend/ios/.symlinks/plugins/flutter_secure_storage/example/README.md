# flutter_secure_storage_example

Demonstrates how to use the flutter_secure_storage plugin.

## Integration Tests
Run the following command

```
flutter drive --target=test_driver/app.dart
```