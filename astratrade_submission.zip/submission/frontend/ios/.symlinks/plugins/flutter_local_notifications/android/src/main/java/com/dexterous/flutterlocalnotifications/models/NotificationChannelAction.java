package com.dexterous.flutterlocalnotifications.models;

import androidx.annotation.Keep;

@Keep
public enum NotificationChannelAction {
  CreateIfNotExists,
  Update
}
