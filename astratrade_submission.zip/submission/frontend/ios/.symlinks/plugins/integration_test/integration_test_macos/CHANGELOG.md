## 0.0.2

* Renames package to integration_test_macos.

## 0.0.1+1

* Remove Android folder from `e2e_macos`.

## 0.0.1

* Initial release
