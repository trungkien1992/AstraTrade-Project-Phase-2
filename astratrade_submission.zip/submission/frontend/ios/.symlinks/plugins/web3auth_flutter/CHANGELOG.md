## 0.0.1

* Initial release with same API surface of the Android and iOS SDK.

## 0.0.2

* Add support for latest Android and iOS SDK API.