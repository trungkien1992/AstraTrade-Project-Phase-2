#import <Flutter/Flutter.h>

@interface Web3AuthFlutterPlugin : NSObject<FlutterPlugin>
@end
