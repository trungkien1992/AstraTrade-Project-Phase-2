// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'my_app.dart' if (dart.library.js_interop) 'my_web_app.dart';

void main() => startApp();
